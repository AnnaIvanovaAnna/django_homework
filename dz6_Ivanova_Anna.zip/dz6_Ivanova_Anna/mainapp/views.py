from .models import ProductCategory, Product
from basketapp.models import Basket
from django.shortcuts import render, get_object_or_404
import random

# Create your views here.
def main(request):
	trending_products = Product.objects.all().order_by('name')[:6]
	products = random.choices(Product.objects.all())
	content={
	'trending_products':trending_products,
	'products':products
	}
	return render(request, 'mainapp/index.html',content)

def product(request,pk=None):
	title='Products'
	products = random.choices(Product.objects.all())
	same_products = Product.objects.all().order_by('price')[:9]
	content = {
	'title': title,
	'same_products': same_products,
	'products':products
	}
	return render(request, 'mainapp/product.html',content)
    
def contact_us(request):
	products = random.choices(Product.objects.all())
	content={
	'products':products
	}
	return render(request, 'mainapp/contact_us.html',content)

def product_details(request,pk):
	if pk:
		if pk == '0':
			category = {'name': 'все'}
			products = random.choices(Product.objects.all())
		else:
			products = Product.objects.filter(id=pk)

	basket = []
	if request.user.is_authenticated:
		basket = Basket.objects.filter(user=request.user)

	related_products = getRelatedProducts(products)
	
	title = 'product_details'
	content = {'title': title,"related_products":related_products,'products':products,'basket':basket}
	return render(request, 'mainapp/product_details.html',content)


def getRelatedProducts(products):
	for product in products:
		related_products = Product.objects.filter(category=product.category).\
		exclude(pk=product.pk)[:4]
	return related_products