from django.apps import AppConfig


class BasketappConfig(AppConfig):
    name = 'basketapp'
