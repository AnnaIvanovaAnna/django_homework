from .models import ProductCategory, Product
from basketapp.models import Basket
from django.shortcuts import render, get_object_or_404

# Create your views here.
def main(request):
	return render(request, 'mainapp/index.html')

def product(request,pk=None):
	title='Products'
	if pk:
		if pk == '0':
			category = {'name': 'все'}
			products = Product.objects.all().order_by('price')
		else:
			category = get_object_or_404(ProductCategory, pk=pk)
			products = Product.objects.filter(category__pk=pk).order_by('price')
		content = {
		'title': title,
		'category': category,
		'products': products,
		'basket':basket
		}
		return render(request, 'mainapp/product_details.html', content)
	same_products = Product.objects.all().order_by('price')[:9]
	content = {
	'title': title,
	'same_products': same_products
	}
	return render(request, 'mainapp/product.html',content)
    
def contact_us(request):
	return render(request, 'mainapp/contact_us.html')

def product_details(request):

	basket = []
	if request.user.is_authenticated:
		basket = Basket.objects.filter(user=request.user)

	title = 'product_details'
	products = Product.objects.all()[8:9]
	related_products= Product.objects.all()[:4]
	content = {'title': title, 'products': products,"related_products":related_products,'basket':basket}
	return render(request, 'mainapp/product_details.html',content)