from .models import ProductCategory, Product
from django.shortcuts import render

# Create your views here.
def main(request):
	return render(request, 'mainapp/index.html')

def product(request):
	return render(request, 'mainapp/product.html')
    
def contact_us(request):
	return render(request, 'mainapp/contact_us.html')

def product_details(request):
	title = 'product_details'
	products = Product.objects.all()[:2]
	content = {'title': title, 'products': products}
	return render(request, 'mainapp/product_details.html',content)